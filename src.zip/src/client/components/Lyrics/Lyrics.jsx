/* eslint-disable react/prop-types */
import React from 'react';
import PropTypes from 'prop-types';
import styles from './style.scss';
import axios from 'axios';

class Lyrics extends React.Component {

  // setLyrics2() {
  //   axios.get("https://api.spotify.com/v1/me/tracks?limit=50", { headers: { "Authorization": 'Bearer ' + accessToken } })
  //     .then(res => {

  //       // get all artist ids and remove duplicates

  //       let uniqArtistIds = uniqBy(res.data.items);

  //     })
  //     .catch(function (error) {
  //       //console.log(error.response);
  //     });
  // }


  // getLyrics() {
  //   let trackTitle = "Skyfall"

  //   let url = "https://cors-anywhere.herokuapp.com/http://api.musixmatch.com/ws/1.1/track.search?q_track=" + trackTitle + "&page_size=10&page=1&s_track_rating=desc&apikey=" + "0bd2d42337eee91e9a126ec59be1aadf";
  //   axios.get(url)
  //     .then(res => {
  //       //return res.data.message.body.lyrics;

  //       let track_id = res.data.message.body.track_list[0].track.track_id;
  //       console.log("lyrics sssssssssssssssssssssssssssss")
  //       console.log(track_id)
  //       return this.getLyrics2(track_id)
  //       //setState({ track_list: track_list, heading: "Search Results" });

  //       // let url = "https://cors-anywhere.herokuapp.com/http://api.musixmatch.com/ws/1.1/track.lyrics.get?track_id=" + track_id + "&apikey=" + "0bd2d42337eee91e9a126ec59be1aadf";
  //       // axios.get(url)
  //       //   .then(res => {
  //       //     return res.data.message.body.lyrics.lyrics_body;
  //       //     //lyrics22 = res.data.message.body.lyrics.lyrics_body;


  //       //   })
  //       //   .catch(function (error) {
  //       //     //console.log(error.response);
  //       //   });
  //     })
  //     .catch(function (error) {
  //       //console.log(error.response);
  //     });
  // }

  //  getLyrics2(track_id) {

  //   //let url = "https://cors-anywhere.herokuapp.com/http://api.musixmatch.com/ws/1.1/track.lyrics.get?track_id=" + track_id + "&apikey=" + "0bd2d42337eee91e9a126ec59be1aadf";
  //   let url = "https://cors-anywhere.herokuapp.com/http://api.musixmatch.com/ws/1.1/track.lyrics.get?track_id=31288729&apikey=" + "0bd2d42337eee91e9a126ec59be1aadf";
    
  //   axios.get(url)
  //     .then(res => {
  //       console.log (res.data.message.body.lyrics.lyrics_body)
  //       return res.data.message.body.lyrics.lyrics_body;

  //       //res.data.message.body.lyrics.lyrics_body 31288729


  //     })
  //     .catch(function (error) {
  //       //console.log(error.response);
  //     });
  // }

  render() {
    console.log("Song ..... " + this.props.song)
    return (

  
      <div className={styles.lyric_header_container}>
      
      
        {
           this.props.lyrics != "" ? 
           (<i>Lyrics&nbsp; ~~~ &nbsp;&nbsp;{this.props.lyrics}</i>) : ""

          
          
        }

        

      </div>
    )
  }
}


export default Lyrics;
